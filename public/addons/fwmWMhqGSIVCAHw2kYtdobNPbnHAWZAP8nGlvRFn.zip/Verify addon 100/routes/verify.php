<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Verify\HomeController;
use App\Http\Controllers\Verify\SettingController;
use App\Http\Controllers\Verify\VerifyEmailController;

Route::group(['prefix' =>'verify'], function () {
    Route::get('/create', [SettingController::class, 'create'])->name('setting.create');
    Route::get('/my_list', [VerifyEmailController::class, 'myList'])->name('my_list');
    Route::post('/my_list', [VerifyEmailController::class, 'myList'])->name('my_list');
    Route::post('/save_email', [HomeController::class, 'saveEmail'])->name('saveEmail');
    Route::post('/downloadFile', [HomeController::class, 'downloadFile'])->name('downloadFile');
    Route::post('/deleteCsvFile', [HomeController::class, 'deleteCsvFile'])->name('deleteCsvFile');
    Route::post('/taskCancel', [HomeController::class, 'taskCancel'])->name('taskCancel');
    Route::post('/verify_per_count', [VerifyEmailController::class, 'verify_per_count'])->name('verify_per_count');
    Route::post('/email_verify', [VerifyEmailController::class, 'email_verify'])->name('email_verify');
    Route::post('/prefix_verify_emails', [VerifyEmailController::class, 'prefix_verify_emails'])->name('prefix_verify_emails');
    Route::post('/scan_mail_settings', [SettingController::class, 'scan_mail_settings'])->name('scan_mail_settings');
});