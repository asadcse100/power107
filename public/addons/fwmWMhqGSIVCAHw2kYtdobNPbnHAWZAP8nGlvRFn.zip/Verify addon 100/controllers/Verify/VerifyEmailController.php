<?php

namespace App\Http\Controllers\Verify;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\verify\EmailCategory;
use App\Models\verify\SiteOption;
use App\Models\verify\UserEmailList;
use App\Models\verify\Task;
use App\Models\MessageInfo;
use App\Models\Home;
use DB;

class VerifyEmailController extends Controller
{
    public $port = 25;
    protected $stream = false;
    public $from = 'localhost'; // change this $from email to yours
    protected $stream_timeout_wait = 30;
    const CRLF = "\r\n";
    public $email;
    protected $domain;
    protected $email_acc;
    public $debug;
    public $status;
    protected $mx_records;
    protected $print;
    protected $user_id;
    protected $catchAllCehked = false;
    protected $last_code;
    const EmailRegularExpr = "^([-!#\$%&'*+./0-9=?A-Z^_`a-z{|}~])+@([-!#\$%&'*+/0-9=?A-Z^_`a-z{|}~]+\\.)+[a-zA-Z]{2,24}\$";
    protected $EMAIL_VALIDATION_STATUS_SYNTAX_ERROR = 'syntax error';
    protected $EMAIL_VALIDATION_STATUS_OK = 0;
    protected $EMAIL_VALIDATION_STATUS_DOMAIN_NOT_FOUND = 'domain not found';
    protected $EMAIL_VALIDATION_STATUS_DOMAIN_MX_NOT_FOUND = 'domain mx record not found';
    protected $EMAIL_VALIDATION_STATUS_GET_HOST_FAILED = 'failed to verify host';
    protected $EMAIL_VALIDATION_STATUS_DISPOSABLE_EMAIL = 'email domain is disposable';
    protected $EMAIL_VALIDATION_STATUS_SMTP_CONNECTION_FAILED = 'smtp connection Failed';
    protected $EMAIL_VALIDATION_STATUS_CATCH_ALL_SERVER = 'Catch-All mail server';
    protected $EMAIL_VALIDATION_STATUS_INVALID_USER = 'Invalid User Id Provided';
    protected $validation_status_code = '0';

    /**
     * Set Emails, Domains, Check DNS record and finaly verify email etc
     */
    public function __construct($email = NULL, $user_id = 0, $print = false)
    {
        $this->print = $print;
        $this->port = self::get_site_option()->scan_port;
        $this->from = self::get_site_option()->scan_mail;
        $this->stream_timeout_wait = self::get_site_option()->scan_time_out;
        $this->status = array(0, 'status' => 'unknown', 'reasons' => 'Mail server error', 'safe_to_send' => 'No', 'email_score' => 0, 'bounce_type' => '', 'type' => '');

        if ($user_id == 0) {
            $this->markAsInvalid();
            $this->setReason($this->EMAIL_VALIDATION_STATUS_INVALID_USER);
            $this->debug[] = 'Invalid User Found...';
            return;
        }

        // first check if email is correct in format...
        if (filter_var($email, FILTER_VALIDATE_EMAIL) && preg_match('/' . str_replace('/', '\\/', self::EmailRegularExpr) . '/', $email)) {
            // debugger;
            $this->email = $email;
            // get domain or hostname from email address
            $this->domain = $this->getDomainFromEmail($this->email);
            $this->email_acc = $this->getEmailAccFromEmail($this->email);
            $email_acc = $this->email_acc;

            if (strpos($email_acc, '\'')) {
                $this->markAsInvalid();
                $this->setReason($this->EMAIL_VALIDATION_STATUS_SYNTAX_ERROR);
                $this->debug[] = 'Incorrect Email Adddress Found...';
                return;
            }
            // check if email is disposible...
            $domainD = $this->domain;
            //$disposable = $this->db->select( "SELECT * FROM email_category WHERE e_type = 'Disposable Account' AND (name = '$this->email_acc' OR name = '{$this->domain}') " );
            $disposable = EmailCategory::where('e_type', 'Disposable Account')->where('name', $domainD)->count();
            // check if domain is in disposable db
            if ($disposable > 0) {
                $this->debug[] = 'Email Domain is Disposable...';
                $this->markAsInvalid();
                $this->setReason($this->EMAIL_VALIDATION_STATUS_DISPOSABLE_EMAIL);
                $this->status['type'] = 'Disposable Account';
            } else {
                // check if domain has MX DNS record
                if ($this->checkDNS()) {
                    $this->debug[] = 'Valid Email Domain DNS Found...';
                    if ($this->getMXrecords()) {
                        $this->debug[] = 'Valid Email Domain MX Records Found...';
                        if ($this->connect()) {
                            $this->verify();
                        }
                    } else {
                        $this->markAsInvalid();
                        $this->setReason($this->EMAIL_VALIDATION_STATUS_DOMAIN_MX_NOT_FOUND);
                        $this->debug[] = 'No MX Records Found...';
                    }
                } else {
                    $this->markAsInvalid();
                    $this->setReason($this->EMAIL_VALIDATION_STATUS_DOMAIN_NOT_FOUND);
                    $this->debug[] = 'Invalid Email Domain DNS Found...';
                }
            }
        } else {
            $this->markAsInvalid();
            $this->setReason($this->EMAIL_VALIDATION_STATUS_SYNTAX_ERROR);
            $this->debug[] = 'Incorrect Email Adddress Found...';
        }
        if ($this->print) {
            echo '<pre>';
            print_r(array_map('htmlentities', $this->debug));
            echo '</pre>';
        }
    }

    public function myList()
    {
        return view('verifier.my_list');
    }

    /** 
     * Get Domain part from full email address
     * @return string return only domain
     */
    public function getDomainFromEmail($email)
    {
        $email_address = explode('@', $email);
        $domain = array_pop($email_address);
        return $domain;
    }

    /** 
     * Get Email username part from full email address
     * @return string return only domain
     */
    public function getEmailAccFromEmail($email)
    {
        $email_address = explode('@', $email);
        $domain = array_shift($email_address);
        return $domain;
    }

    // set current email as Valid
    public function markAsValid()
    {
        $this->status[0] = true;
    }

    // set current email as Invalid
    public function markAsInvalid()
    {
        $this->status[0] = false;
        $this->status['status'] = 'invalid';
        $this->status['bounce_type'] = 'hard';
    }

    // set current email verify reason
    public function setReason($reason)
    {
        $this->status['reasons'] = $reason;
    }

    /** 
     * Check Domain MX DNS Records 
     * @return boolean return MX records if found
     */
    public function checkDNS()
    {
        return checkdnsrr($this->domain, 'MX');
    }

    /** 
     * Get Domain MX Records 
     * @return array return MX records if found or empty array
     */
    public function getMXrecords()
    {
        $mx_records = array();
        $mx_weights = array();
        // Get the records
        if (getmxrr($this->domain, $mx_records, $mx_weights)) {
            $mx_records = array_combine($mx_weights, $mx_records);
            // records sorted by MX Weight
            ksort($mx_records);
            if (!empty($mx_records)) {
                $this->mx_records = $mx_records;
                return true;
            }
        }
        return false;
    }

    /** 
     * Connect To Socket Server
     * @return boolean True if connection success
     */

    public function connect()
    {
        foreach ($this->mx_records as $host) {
            $this->stream = @fsockopen($host, $this->port, $errno, $errstr, $this->stream_timeout_wait);
            if ($this->stream !== false) {
                stream_set_timeout($this->stream, $this->stream_timeout_wait);
                stream_set_blocking($this->stream, 1);
                if ($this->_streamCode('220') > 0) {
                    //$this->debug[] = "Connection success {$host}";                    
                    break;
                } else {
                    fclose($this->stream);
                    $this->stream = false;
                }
            } else {
                if ($errno == 0) {
                    $this->debug[] = 'Problem initializing the socket';
                    $this->markAsInvalid();
                    $this->setReason($this->EMAIL_VALIDATION_STATUS_SMTP_CONNECTION_FAILED);
                }
            }
        }
        if ($this->stream === false) {
            $this->debug[] = 'All connection fails';
            $this->markAsInvalid();
            $this->setReason($this->EMAIL_VALIDATION_STATUS_SMTP_CONNECTION_FAILED);
            return false;
        }

        return true;
    }

    /** 
     * disconnect from Socket Server
     * @return null
     */
    public function disconnect()
    {
        @fclose($this->stream);
    }

    /** 
     * Validate email
     * @param string $email Email address 
     * @return boolean True if the valid email exist 
     */
    public function verify()
    {
        if ($this->is_domain_catch_all_enabled($this->getDomainFromEmail($this->email))) {
            $this->debug[] = "Email Domain is Catch-All Enabled";
            $this->markAsInvalid();
            $this->setReason($this->EMAIL_VALIDATION_STATUS_CATCH_ALL_SERVER);
            $this->status['status'] = 'catch all';
            $this->status['safe_to_send'] = 'Risky';
            $this->status['email_score'] = '0.5';
        } else {

            if ($this->validated($this->email)) {
                $this->markAsValid();
                $this->setReason('success');
                $this->status['status'] = 'valid';
                $this->status['safe_to_send'] = 'Yes';
                $this->status['email_score'] = '1';
            } else {
                $this->markAsInvalid();
                $this->setReason('invalid email address');
            }
        }
        $this->disconnect();
    }

    /** 
     * check if email domain is Cache-All
     * @param string $domain Email domain 
     * @return boolean True if the domain is Cache-All
     */
    public function is_domain_catch_all_enabled($domain)
    {
        $catch_all_check_status = '';
        $random_c = $this->getRandomString();
        $catchAll_email = $random_c . '@' . $domain;
        $email_acc = $this->getEmailAccFromEmail($this->email);
        $email_dom = $this->getDomainFromEmail($this->email);
        $email_type_read = EmailCategory::where('name', $email_acc)->orwhere('name', $email_dom)->first();

        if (!empty($email_type_read)) {
            $email_type = $email_type_read['e_type'];
            $catch_all_check_status = $email_type_read['catch_all_check'];
            $this->status['type'] = $email_type;
        }

        $skip_catchall = $this->mx_records;
        $public_catch_skip = preg_grep("/(google|outlook|ymail|yahoo|gmail)/i", $skip_catchall);

        if (!$public_catch_skip) {
            if ($catch_all_check_status != '0') {
                $this->debug[] = 'Checking Catch-All Server...';
                $code = $this->validated($catchAll_email);
                $this->catchAllCehked = true;
                if ($code) return true;
            }
        }
        return false;
    }

    /** 
     * Validate email
     * @param string $email Email address 
     * @return boolean True if the valid email exist 
     */
    public function validated($email = NULL)
    {
        $valid = true;
        if ($this->catchAllCehked == false) {
            $this->_streamQuery('HELO ' . $this->getDomainFromEmail($email));
            if ($this->_streamCode('250') > 0) {
                $this->_streamQuery("MAIL FROM: <$this->from>");
                if ($this->_streamCode('250') > 0) {
                    $valid = true;
                } else {
                    $valid = false;
                }
            } else {
                $valid = false;
            }
        }
        if ($valid) {
            $this->_streamQuery("RCPT TO: <{$email}>");
            if ($this->_streamCode('250') > 0) {
                $valid = true;
            } else {
                $valid = false;
            }

            if ($this->catchAllCehked !== false) {
                $this->_streamQuery("RSET");
                $this->_streamQuery("QUIT");
            }
        }
        return $valid;
    }

    /** 
     * writes the contents of string to the file stream pointed to by handle 
     * If an error occurs, returns FALSE. 
     * @access protected 
     * @param string $string The string that is to be written 
     * @return string Returns a result code, as an integer. 
     */
    protected function _streamQuery($query)
    {
        $this->debug[] = $query;
        return (@fputs($this->stream, $query . self::CRLF));
    }

    /** 
     * Reads all the line long the answer and analyze it. 
     * If an error occurs, returns FALSE 
     * @access protected 
     * @return string Response 
     */
    protected function _streamResponse($timed = 0)
    {
        for ($line = "";;) {
            $info = stream_get_meta_data($this->stream);
            if ($info['timed_out']) return $line;
            if (@feof($this->stream)) return (0);
            $line .= @fgets($this->stream, 100);
            $length = strlen($line);
            if ($length >= 2 && substr($line, $length - 2, 2) == "\r\n") {
                $line = substr($line, 0, $length - 2);
                $this->debug[] = $line;
                return ($line);
            }
        }
    }

    /** 
     * Get Response code from Response 
     * @param string $code 
     * @return string 
     */
    protected function _streamCode($code)
    {
        while (($line = $this->_streamResponse($this->stream))) {
            $end = strcspn($line, ' -');
            $this->last_code = substr($line, 0, $end);
            if (strcmp($this->last_code, $code)) return (0);
            if (!strcmp(substr($line, strlen($this->last_code), 1), " ")) return (1);
        }
        return (0);
    }

    public function getRandomString($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return strtolower($randomString);
    }

    public function get_site_option($option = '')
    {
        $scanMail = SiteOption::select('scan_mail', 'scan_port', 'scan_time_out')->first();
        return $scanMail;
    }

    public function verify_per_count(Request $request)
    {
        if (isset($request->filename) && isset($request->uid)) {
            $csv_file_name = $request->filename;
            $user_id = $request->uid;
            $verify_per_status = 0;
            $result_arr = [];

            $csv_result['t_email'] = UserEmailList::select('email_name')->count();
            $csv_result['create_time'] = UserEmailList::select('created_at')->min('created_at');
            $csv_result['count_valid'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_status', 'valid')->where('user_id', $user_id)->count();
            $csv_result['count_invalid'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_status', 'invalid')->where('user_id', $user_id)->count();
            $csv_result['count_catchall'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_status', 'catch all')->where('user_id', $user_id)->count();
            $csv_result['count_unknown'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_status', 'unknown')->where('user_id', $user_id)->count();
            $csv_result['count_not_verify'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_status', 'Not Verify')->where('user_id', $user_id)->count();
            $csv_result['count_syntax'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('verification_response', 'syntax error')->where('user_id', $user_id)->count();
            $csv_result['count_free'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_type', 'Free Account')->where('user_id', $user_id)->count();
            $csv_result['count_role'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_type', 'Role Account')->where('user_id', $user_id)->count();
            $csv_result['count_disposable'] = UserEmailList::select('email_name')->where('file_name', $csv_file_name)->where('email_type', 'Disposable Account')->where('user_id', $user_id)->count();

            if ($csv_result > 0) {
                $t_email = $csv_result['t_email'];
                $count_valid = $csv_result['count_valid'];
                $count_invalid = $csv_result['count_invalid'];
                $count_catchall = $csv_result['count_catchall'];
                $count_unknown = $csv_result['count_unknown'];
                $total_check_validation = $count_valid + $count_invalid + $count_catchall + $count_unknown;
                $csv_name_ex = preg_replace('/\\.[^.\\s]{3,4}$/', '', $csv_file_name);
                $verify_per_status = ceil((($count_valid + $count_invalid + $count_catchall + $count_unknown) / $t_email) * 100);
            }

            foreach ($csv_result as $key => $value) {
                $result_name = str_replace('count_', '', $key);
                $id = $result_name . '_' . $csv_name_ex;
                $result_arr[][$id] = $value;
            }
            echo json_encode([
                'percent' => $verify_per_status,
                'total_verify' => $total_check_validation,
                'details' => $result_arr
            ]);
        }
    }

    public function prefix_verify_emails(Request $request)
    {
        $user_id = $request->uid;
        $filename = $request->filename;
        // each time fetch how many emails to verify
        $limit = 10;
        // add the new task for this user
        
        $task = new Task;
        $task->file_name = $filename;
        $task->user_id = $user_id;
        $task->save();

        // check if user verifying status is running...
        $running = Task::where('user_id', $user_id)->where('file_name', $filename)->where('status', 'running')->count();

        if ($running == 0) {
            Task::where('file_name', $filename)->where('user_id', $user_id)->delete();
            exit();
        }
        $check_email = UserEmailList::where('user_id', $user_id)->where('file_name', $filename)->where('email_status', 'Not Verify')->count();
        $email_st = UserEmailList::where('user_id', $user_id)->where('file_name', $filename)->where('email_status', 'Not Verify')->get();
        if ($check_email > 0) {

            foreach ($email_st as $row) {
                $running = Task::where('file_name', $filename)->where('user_id', $user_id)->where('status', 'running')->count();

                if ($running == 0) {
                    Task::where('file_name', $filename)->where('user_id', $user_id)->delete();
                    exit();
                }

                $status = [0, 'status' => 'unknown', 'reasons' => 'Mail server error', 'safe_to_send' => 'No', 'email_score' => 0, 'bounce_type' => '', 'type' => ''];
                $email_id = $row['id'];
                $toemail = $row['email_name'];
                $bulk_status = $request->bulk_status;
                $follwup_status = $request->follwup_status;

                $email_arr = explode('@', $toemail);
                $email_acc = $email_arr[0];
                $email_dom = $email_arr[1];
                $verify = new VerifyEmailController($toemail, $user_id);
                //Now working main
                $status = $verify->status;
                DB::table('user_email_lists')->where('id', $email_id)->update([
                    'email_status' => $status['status'],
                    'email_type' => $status['type'],
                    'safe_to_send' => $status['safe_to_send'],
                    'verification_response' => $status['reasons'],
                    'score' => $status['email_score'],
                    'bounce_type' => $status['bounce_type'],
                    'bulk_status' => $bulk_status,
                    'follwup_status' => $follwup_status,
                    'email_acc' => $email_acc,
                    'email_dom' => $email_dom
                ]);
                if ($bulk_status == 1) {
                    $getEmails = UserEmailList::where('user_id', $user_id)->where('bulk_status', 1)->where('email_status', 'valid')->get();
                    foreach ($getEmails as $email) {
                        $home = new Home;
                        $home->user_id = $user_id;
                        $home->email = $email->email_name;
                        $home->status = 0;
                        $home->save();
                    }
                }
            }
            
        } else {
            Task::where('file_name', $filename)->where('user_id', $user_id)->delete();
            exit();
        }
    }
}
