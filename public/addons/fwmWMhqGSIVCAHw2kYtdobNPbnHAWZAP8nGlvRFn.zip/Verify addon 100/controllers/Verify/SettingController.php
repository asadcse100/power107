<?php

namespace App\Http\Controllers\Verify;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\verify\EmailCategory;
use App\Models\verify\SiteOption;
use App\Models\verify\Timer;
use DB;

class SettingController extends Controller
{

public function index()
{
  //code
}

public function create()
{
  $data = [];
  $veriferDara = SiteOption::first();
  $data['scan_mail'] = $veriferDara->scan_mail;
  $data['scan_port'] = $veriferDara->scan_port;
  $data['scan_timeout'] = $veriferDara->scan_time_out;
  return view('verifier.settings', $data);
}

public function scan_mail_settings(Request $request)
{
    $scan_from = $request->scan_from;
    $timeout = $request->timeout;
    $scan_port = $request->scan_port;
    
        $site_options_count = SiteOption::count();
        if($site_options_count > 0){
          // $site_options_update_sql = "UPDATE site_options SET scan_time_out = '$timeout',scan_port = '$scan_port',scan_mail = '$scan_from' ";
          // SiteOption::where('scan_time_out', $timeout)->where('scan_port', $scan_port)->where('scan_mail',$scan_from)->update();
          DB::table('site_options')->update([
            'scan_time_out' => $timeout,
            'scan_port' => $scan_port,
            'scan_mail' => $scan_from
          ]);
        }else{
          // $site_options_update_sql = "INSERT INTO site_options (scan_time_out, scan_port, scan_mail) VALUES ('$timeout', '$scan_port', '$scan_from') ";
          $siteOption = new SiteOption;

          $siteOption->scan_time_out = Input::get('scan_time_out');
          $siteOption->scan_port = Input::get('scan_port');
          $siteOption->scan_mail = Input::get('scan_mail');
          $siteOption->save();
        }

    
    return view('verifier.settings');

}

  
}
