<?php

namespace App\Http\Controllers\Verify;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\verify\EmailCategory;
use App\Models\verify\SiteOption;
use App\Models\verify\UserEmailList;
use App\Models\verify\Task;
use App\Models\verify\VerifyEmail;
use App\Models\User;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\VerifyLeadsImport;
use App\Exports\VerifyExport;
use Response;

class HomeController extends Controller
{
    
  public function userWallet()
  {
    $user_id = Auth::id(); 
    echo $user_id; exit();

    $cost_per_scan = '';
    $site_options_read = SiteOption::all();

    if ( $site_options_read ) {         
      if ( !empty($site_options_read) ) {          
        $cost_per_scan = $site_options_read['cost_per_scan'];
      }
    }

    $credit_payment = '';
    $credit_payment_read = User::where('id', $user_id)->get();

    if ( $credit_payment_read ) {    
      if ( !empty($credit_payment_read) ) {
        $credit_payment = $credit_payment_read['credit_amount'];
      }
    }
    $deduct_credit_q = User::where('id', $user_id)->where('credit_amount',">",0)->update(['credit_amount'=>$credit_payment-$cost_per_scan]);
    return $deduct_credit_q;
  }

    public function timeCheck(Request $request)
    {
    extract($request);
    $user_id = Auth::id(); 
    if(is_numeric($request->emails)){

    $dates = new DateTime('now', new DateTimeZone('UTC') ); //php international timezone
    $dates = $dates->format('Y-m-d H:i:s'); //formate as 2019-7-23 12:34:12
    $user_read3 = Timer::where('user_id', $user_id)->get();
      if($user_read3){
        $time_count = $user_read3['time_count'];
        $t_dates = strtotime($dates);
        $start_date = strtotime($time_count);
        $time_left =($t_dates - $start_date)/60; //formate time in minute
        if($time_left > $user_read3['time_range']){
        $read18 = Timer::where('user_id', $user_id)->update(['last_send'=>$emails], ['time_count'=>$dates]); // update send mail counting and time;
        if ($read18) {
          echo 'ok';
        }
        }else{
        $range = $user_read3['e_range'];
        $send = $user_read3['last_send'];
        $email_left = $range - $send;
        if($email_left >= $emails){
          $count_email = $send + $emails;
          $read19 = Timer::where('user_id', $user_id)->update(['last_send'=>$count_email]); // update send mail if time exits;
          if ($read19) {
          echo 'ok';
          }
        }else{
          echo 'error';
        }
        }
      }
    } else {
      echo 'unknown_error';
    }
    }
   
    public function taskCancel(Request $request)
    {
        $user_id = $request->uid;
        $filename = $request->filename;
        if( !empty( $filename ) ){              
        $delete_task_read = Task::where('file_name', $filename)->where('user_id', $user_id)->first();
          if ( !empty($delete_task_read) ) {                     
              Task::where('file_name', $filename)->delete();
          }
        }
        echo json_encode(['status' => 'ok']); exit();
    }

      public function saveEmail(Request $request)
      {
        Excel::import(new VerifyLeadsImport, request()->file('filename'));
        return back()->with('success','Leads Upload Successfully!');
      }

      public function quickMailVerify()
      {
        $user_id = $_SESSION['id'];
        $email = 0;
        extract( $_POST );
        set_time_limit(0);
        $credit = VerifyEmail::check_user_credit( $user_id );
        $wallet_system = VerifyEmail::get_site_option( 'wallet_system' );

        if ( $wallet_system === 'TRUE' && $credit && $credit < VerifyEmail::get_site_option( 'cost_per_scan' ) ) {
            $status['safe_to_send'] = '';            
            $status['type'] = '';            
            $status['status'] = "Couldn't verify";            
            $status['reasons'] = "Insufficient balance";            
        }else{

            if ( $wallet_system === 'TRUE' ) VerifyEmail::deduct_credit( $user_id );            
            $verify = new VerifyEmail( $email, $user_id );
            $status = $verify->status;
        }

        echo json_encode(['index' => $index, 'safetosend' => $status['safe_to_send'], 'status' => $status['status'], 'type' => $status['type'], 'reasons' => $status['reasons'],'debug' => $verify->debug]);

        exit();
      }

    public function downloadFile(Request $request)
    {
      if($request->valid && $request->catchall){
        $emailArray = UserEmailList::select('email_name')->where('file_name', $request->filename)->where('user_id', $request->user_id)->whereIn('email_status', [$request->valid,$request->catchall])->get();
      }elseif($request->catchall){
        $emailArray = UserEmailList::select('email_name')->where('file_name', $request->filename)->where('user_id', $request->user_id)->where('email_status', $request->catchall)->get();
      }else{
        $emailArray = UserEmailList::select('email_name')->where('file_name', $request->filename)->where('user_id', $request->user_id)->where('email_status', $request->valid)->get();
      }
      
      $export = new VerifyExport($emailArray->toArray());
      if($request->type == 'xlsx'){        
        return Excel::download($export, $request->filename.'.xlsx');
      }elseif($request->type == 'xls'){
        return Excel::download($export, $request->filename.'.xls');
      }elseif($request->type == 'text'){
          // prepare content
          // $logs = Log::all();
          $content = null;
          $arr = $emailArray->toArray();
          foreach ($arr as $log) {            
            $content .= $log['email_name'];            
            $content .= "\n";
          }

          // file name that will be used in the download
          $fileName = $request->filename.'.txt';

          // use headers in order to generate the download
          $headers = [
            'Content-type' => 'text/plain', 
            'Content-Disposition' => sprintf('attachment; filename="%s"', $fileName),
            // 'Content-Length' => sizeof($content)
          ];

          // make a response, with the content, a 200 response code and the headers
          return Response::make($content, 200, $headers);
      }else{
        return Excel::download($export, $request->filename.'.csv');
      }
    }

    public function deleteCsvFile()
    {
        $filename = $_POST['filename'];
        $user_id = $_POST['uid'];
        if(!empty($filename)){
        $delete_task_read = UserEmailList::where('file_name', $filename)->where('user_id', $user_id)->get();
        if (!empty($delete_task_read)) {
            $read_task_delete = UserEmailList::where('file_name', $filename)->where('user_id', $user_id)->delete();
            $delete_task_read = Task::where('file_name', $filename)->where('user_id', $user_id)->get();
            if (!empty($delete_task_read)) {
            $read_task_delete = Task::where('file_name', $filename)->where('user_id', $user_id)->delete();
            }
        }
        }
            header('Content-Type: application/json');
            echo json_encode(['status' => 'ok']);
    }

}
