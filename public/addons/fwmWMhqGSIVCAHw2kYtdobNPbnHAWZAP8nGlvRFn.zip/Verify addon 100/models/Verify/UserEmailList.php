<?php

namespace App\Models\Verify;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Country
 * @package App\Models
 * @version February 29, 2020, 10:29 am UTC
 *
 * @property integer name
 * @property integer status
 */
class UserEmailList extends Model
{
    //use SoftDeletes;
    protected $fillable = [
        'user_id',
        'file_name',
        'email_name',
        'email_status',
    ];
    public $table = 'user_email_lists';

    
}
