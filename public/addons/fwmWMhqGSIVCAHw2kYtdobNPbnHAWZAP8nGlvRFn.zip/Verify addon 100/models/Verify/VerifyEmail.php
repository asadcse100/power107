<?php

namespace App\Models\Verify;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Country
 * @package App\Models
 * @version February 29, 2020, 10:29 am UTC
 *
 * @property integer name
 * @property integer status
 */
class VerifyEmail extends Model
{
    //use SoftDeletes;

    public $table = 'all_leads';

    protected function getValid()
    {
        $getValid = UserEmailList::select('email_name','email_status')->get();

	return $getValid;
    }
}
