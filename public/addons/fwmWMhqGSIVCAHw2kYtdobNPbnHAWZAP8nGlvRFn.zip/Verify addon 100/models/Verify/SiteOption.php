<?php

namespace App\Models\Verify;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Country
 * @package App\Models
 * @version February 29, 2020, 10:29 am UTC
 *
 * @property integer name
 * @property integer status
 */
class SiteOption extends Model
{
    //use SoftDeletes;

    public $table = 'site_options';

    
}
