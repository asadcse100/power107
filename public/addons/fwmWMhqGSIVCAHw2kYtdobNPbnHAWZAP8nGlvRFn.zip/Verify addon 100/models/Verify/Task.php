<?php

namespace App\Models\Verify;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Country
 * @package App\Models
 * @version February 29, 2020, 10:29 am UTC
 *
 * @property integer name
 * @property integer status
 */
class Task extends Model
{
    //use SoftDeletes;
    public $fillable = [
        'file_name',
        'user_id',
        'status'
    ];

    public $table = 'task';

    
}
