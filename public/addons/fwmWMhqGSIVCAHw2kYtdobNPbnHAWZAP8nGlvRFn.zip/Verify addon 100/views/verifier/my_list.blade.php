@extends('layouts.app')
@section('content')
<link href="{{ asset('verifier/css/style.css') }}" rel="stylesheet">
<script src="{{ asset('verifier/js/jquery.min.js') }}"></script>
<div class="container-fluid">
<section class="content-header">
    <h1 class="pull-left">My Listing</h1><hr>
    <h1 class="pull-right">
        <a class="btn btn-sm btn-info pull-right" href="#" id="add_list" data-toggle="modal" data-target="#addList">Add List</a>
    </h1>
</section>
<div class="clearfix"></div>
<div class="content">

    <!-- Start From now loop  -->
    @php
    $user_id = Auth::id();
    $info = \App\Models\Verify\UserEmailList::where('user_id', $user_id)->select('file_name')->GROUPBY('file_name')->ORDERBY('file_name', 'DESC')->get();
    $i = $c = 0;
    @endphp

    @forelse ($info as $file_name)

    @php
    $task_check_status = false;
    $task_count_check = \App\Models\Verify\Task::where('file_name', $file_name->file_name)->count();
    if ($task_count_check > 0) $task_check_status = true;
    $c++;
    $csv_result = [];
    $csv_result['t_email'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->count();
    $csv_result['create_time'] = \App\Models\Verify\UserEmailList::select('created_at')->min('created_at');
    $csv_result['count_valid'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_status', 'valid')->where('user_id', $user_id)->count();
    $csv_result['count_invalid'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_status', 'invalid')->where('user_id', $user_id)->count();
    $csv_result['count_catchall'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_status', 'catch all')->where('user_id', $user_id)->count();
    $csv_result['count_unknown'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_status', 'unknown')->where('user_id', $user_id)->count();
    $csv_result['count_not_verify'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_status', 'Not Verify')->where('user_id', $user_id)->count();
    $csv_result['count_syntax'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('verification_response', 'syntax error')->where('user_id', $user_id)->count();
    $csv_result['count_free'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_type', 'Free Account')->where('user_id', $user_id)->count();
    $csv_result['count_role'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_type', 'Role Account')->where('user_id', $user_id)->count();
    $csv_result['count_disposable'] = \App\Models\Verify\UserEmailList::select('email_name')->where('file_name', $file_name->file_name)->where('email_type', 'Disposable Account')->where('user_id', $user_id)->count();

    $t_email = $csv_result['t_email'];
    $create_time = $csv_result['create_time'];
    $count_valid = $csv_result['count_valid'];
    $count_invalid = $csv_result['count_invalid'];
    $count_catchall = $csv_result['count_catchall'];
    $count_unknown = $csv_result['count_unknown'];
    $count_not_verify = $csv_result['count_not_verify'];
    $count_free = $csv_result['count_free'];
    $count_role = $csv_result['count_role'];
    $count_disposable = $csv_result['count_disposable'];
    $count_syntax = $csv_result['count_syntax'];

    $total_verify = $count_valid + $count_invalid + $count_catchall + $count_unknown;
    $csv_name_ex = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file_name->file_name);
    $verify_per_status = ceil((($count_valid + $count_invalid + $count_catchall + $count_unknown) / $t_email) * 100);
    @endphp

    <div class="box box-primary scan_list" id="mega_bar_{{ $csv_name_ex }}">
        <div class="box-body">
           

            <!-- Result - Second Column -->
            <div class="col-lg-4">
                <!-- Background Gradient Utilities -->
                <div class="card mt-4 mb-4">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th colspan="2">Verified Result <hr>
                                    @if($verify_per_status < 100 && $verify_per_status != 0)
                                        <h4 id="per_count_{{ $csv_name_ex }}">
                                        {{ $verify_per_status}} % ({{ $total_verify }})
                                        </h4>
                                    @endif
                                    </th>
                                </tr>
                                <tr>
                                    <td>
                                        <p>Total : {{ $csv_result['t_email'] }}</p>
                                        <p>Valid : <span id="valid_{{ $csv_name_ex }}">{{ $count_valid }}</span></p>
                                        <p>Invalid: <span id="invalid_{{ $csv_name_ex }}">{{ $count_invalid }}</span></p>
                                        <p>Catch All : <span id="catchall_{{ $csv_name_ex }}">{{ $count_catchall }}</span></p>
                                    </td>
                                    <td>
                                        <p>Syntax Error : <span id="syntax_{{ $csv_name_ex }}">{{ $count_syntax }}</span></p>
                                        <p>Disposable : <span id="disposable_{{ $csv_name_ex }}">{{ $count_disposable }}</span></p>
                                        <p>Unknown: <span id="unknown_{{ $csv_name_ex }}">{{ $count_unknown }}</span></p>
                                    </td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Chart - Third Column -->
            <div class="col-lg-4">
                
                @if($count_not_verify != 0)
                        @if($task_check_status)
                        <div class="preloader" style="display:block" id="preloader_{{ $csv_name_ex }}">
                            <div class="spinner-border text-info" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            <div class="task-cancel-btn">
                                <button data-target='{{ $csv_name_ex }}' type="button" class="btn btn-danger btn-sm task-cancel-btn" name="button">Cancel</button>
                            </div>
                        </div>

                        <button style="display:none;" id="cancel_{{ $csv_name_ex }}" class="btn btn-info btn-icon-split verify_email">
                            <span class="text verify-btn" data-target='{{ $csv_name_ex }}'>Verify</span>
                        </button>
                        <button class="btn btn-warning btn-icon-split verify_email_bulk" id="cancel_{{ $csv_name_ex }}"> 
                            <span class="text verify-bulk-btn" data-target='{{ $csv_name_ex }}'>Verify & Bulk Send</span>
                        </button>
                        <button class="btn btn-info btn-icon-split verify_email_respond" id="cancel_{{ $csv_name_ex }}">
                            <span class="text verify-bulk-followup-btn" data-target='{{ $csv_name_ex }}'>Verify, Bulk & followup Send</span>
                        </button>
                        @else
                        <button class="btn btn-primary btn-icon-split verify_email" id="cancel_{{ $csv_name_ex }}">
                            <span class="text verify-btn" data-target='{{ $csv_name_ex }}'>Verify</span>
                        </button>
                        <button class="btn btn-warning btn-icon-split verify_email_bulk" id="cancel_{{ $csv_name_ex }}"> 
                            <span class="text verify-bulk-btn" data-target='{{ $csv_name_ex }}'>Verify & Bulk Send</span>
                        </button>
                        <button class="btn btn-info btn-icon-split verify_email_respond" id="cancel_{{ $csv_name_ex }}">
                            <span class="text verify-bulk-followup-btn" data-target='{{ $csv_name_ex }}'>Verify, Bulk & followup Send</span>
                        </button>
                        <div class="preloader" id="preloader_{{ $csv_name_ex }}">
                            <div class="spinner-border text-info" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            <div class="task-cancel-btn">
                                <button type="button" class="btn btn-danger btn-sm task-cancel-btn" data-target='{{ $csv_name_ex }}' name="button">Cancel</button>
                            </div>
                        </div>
                        @endif
                        <div class="card-body verify-chart" id='chart_{{ $csv_name_ex }}'>
                            <div class="chart-pie pt-4 pb-2">
                                <canvas id='myChart_{{ $csv_name_ex }}'></canvas>
                                <canvas id='new_myChart_{{ $csv_name_ex }}'></canvas>
                            </div>
                        </div>
                @else
                    <div style="display:block" class="card-body verify-chart" id='chart_{{ $csv_name_ex }}'>
                        <div class="chart-pie pt-4 pb-2">
                            <canvas class="cart_sizing" id='myChart_{{ $csv_name_ex }}'></canvas>
                            <canvas class="cart_sizing" id='new_myChart_{{ $csv_name_ex }}' style="display:none;"></canvas>
                        </div>
                    </div>
                @endif
                <script src="{{ asset('verifier/js/chart.js') }}"></script>
                <script>
                    var ctx = document.getElementById('myChart_{{ $csv_name_ex }}').getContext('2d');
                    var myChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: ['Valid', 'Invalid', 'Catch All', 'Unknown'],
                            datasets: [{
                                label: '# of Votes',
                                data: [{{$count_valid}}, 
                                {{$count_invalid}},
                                {{$count_catchall}},
                                {{$count_unknown}}],
                                backgroundColor: ['#C6E377', '#F16F6F', '#75CAC3', '#C0C0C0'],
                                borderColor: ['#C6E377', '#F16F6F', '#75CAC3', '#C0C0C0'],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            legend: {
                                display: true,
                                position: 'bottom'
                            }
                        }
                    });
                </script>
            </div>
            <div class="col-md-12 col-lg-3">
                <!-- Custom Text Color Utilities -->
                <div class="card shadow mt-4 mb-4">
                    <div class="card-header py-3">
                        <h4 class="m-0 font-weight-bold text-primary">File Name : <span id="filename">{{ $csv_name_ex }}</span></h4>
                    </div>
                    <hr>
                    <div class="card-body">
                        <p class="text-gray-800 p-3 m-0">Created : {{ $create_time }}</p>
                        <button class="btn btn-info" type="button" data-toggle="modal" data-target="#model_csv{{ $csv_name_ex }}">Csv</button>
                        <button class="btn btn-info" type="button" data-toggle="modal" data-target="#model_xlsx{{ $csv_name_ex }}">Xlsx</button>
                        <button class="btn btn-info" type="button" data-toggle="modal" data-target="#model_xls{{ $csv_name_ex }}">Xls</button>
                        <button class="btn btn-info" type="button" data-toggle="modal" data-target="#model_text{{ $csv_name_ex }}">Text</button>
                        <button class="file_delete_btn btn btn-danger" data-target='{{ $csv_name_ex }}'>Delete</button>
                    </div>
                </div>
            </div>
            @if($verify_per_status < 100 && $verify_per_status != 0)
            @php
                $running = \App\Models\Verify\Task::where('file_name', $csv_name_ex)->where('status', 'running')->count();
            @endphp
            @if($running > 0)
            <script>
            $(document).ready(function() {
                var interval_{{$c}} = null;
                interval_{{$c}} = setInterval(updatepercent{{$c}}, 5000);

                function updatepercent{{$c}}() {
                    var csvfile_name_{{$c}} = '{{ $csv_name_ex }}';
                    var csv_name_ex_{{$c}} = '{{ $csv_name_ex }}';
                    var user_id = "{{ $user_id }}";
                    $.ajax({
                        url: "{{ route('verify_per_count') }}",
                        type: "post",
                        data: {
                            filename: csvfile_name_{{$c}},
                            uid: user_id,
                            _token: @json(csrf_token())
                        },
                        success: function(response_{{$c}}) {
                            var obj_{{$c}} = jQuery.parseJSON(response_{{$c}});
                            if (obj_{{$c}}.percent == '100') {
                                clearInterval(interval_{{$c}});
                                $('#per_count_{{ $csv_name_ex }}').html(
                                    '<h6 class="d-inline-block float-right text-success">Complete <a href = "" class="text-primary">Refresh</a> </h6>'
                                );
                            } else {
                                $('#per_count_{{ $csv_name_ex }}').html(obj_{{$c}}
                                    .percent + '% (' + obj_{{$c}}.total_verify + ') ');
                                if (obj_{{$c}}.details !== 'undefined') {
                                    $.each(obj_{{$c}}.details, function() {
                                        var key = Object.keys(this)[0];
                                        var value = this[key];
                                        try {
                                            $('#' + key).text(value);
                                        } catch (e) {
                                            console.log(e);
                                        }
                                    });
                                }
                            }
                        }
                    });
                }
            });
        </script>
        @endif
        @endif
        </div>
    </div>

    <!-- CSV Download Modal -->
<div class="csv_download modal fade" id="model_csv{{ $csv_name_ex }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">CSV Download</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('downloadFile')}}" method="post">
                @csrf
                <input type="text" name="filename" hidden value="{{ $csv_name_ex }}">
                <input type="text" name="user_id" hidden value="{{ $user_id }}">
                <input type="text" name="type" hidden value="csv">
                <div class="modal-body row">
                    <div class="col-sm-6">
                        <div class="form-group form-check">
                            <input type="checkbox" name="valid" value="valid" checked class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_valid == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables <span class="badge badge-success">{{ $count_valid }}</span></label>
                        </div>

                        <div class="form-group form-check">
                            <input type="checkbox" name="catchall" value="catch all" class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_catchall == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables with Risk <span class="badge badge-info">{{ $count_catchall }}</span></label>
                        </div>

                    </div>

                </div>
                <script>
                    function cbChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_all_{{ $i }}");
                        cbs[0].checked = false;
                    }

                    function allChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_sub_{{ $i }}");
                        for (var i = 0; i < cbs.length; i++) {
                            cbs[i].checked = false;
                        }
                    }
                </script>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Download</button>
                </div>
            </form>
        </div>
    </div>
</div>

    <!-- XLSX Download Modal -->
<div class="csv_download modal fade" id="model_xlsx{{ $csv_name_ex }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">XLSX Download</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('downloadFile')}}" method="post">
                @csrf
                <input type="text" name="filename" hidden value="{{ $csv_name_ex }}">
                <input type="text" name="user_id" hidden value="{{ $user_id }}">
                <input type="text" name="type" hidden value="xlsx">
                <div class="modal-body row">
                    <div class="col-sm-6">
                        <div class="form-group form-check">
                            <input type="checkbox" name="valid" value="valid" checked class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_valid == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables <span class="badge badge-success">{{ $count_valid }}</span></label>
                        </div>

                        <div class="form-group form-check">
                            <input type="checkbox" name="catchall" value="catch all" class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_catchall == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables with Risk <span class="badge badge-info">{{ $count_catchall }}</span></label>
                        </div>

                    </div>

                </div>
                <script>
                    function cbChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_all_{{ $i }}");
                        cbs[0].checked = false;
                    }

                    function allChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_sub_{{ $i }}");
                        for (var i = 0; i < cbs.length; i++) {
                            cbs[i].checked = false;
                        }
                    }
                </script>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Download</button>
                </div>
            </form>
        </div>
    </div>
</div>
    <!-- XLS Download Modal -->
<div class="csv_download modal fade" id="model_xls{{ $csv_name_ex }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">XLS Download</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('downloadFile')}}" method="post">
                @csrf
                <input type="text" name="filename" hidden value="{{ $csv_name_ex }}">
                <input type="text" name="user_id" hidden value="{{ $user_id }}">
                <input type="text" name="type" hidden value="xls">
                <div class="modal-body row">
                    <div class="col-sm-6">
                        <div class="form-group form-check">
                            <input type="checkbox" name="valid" value="valid" checked class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_valid == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables <span class="badge badge-success">{{ $count_valid }}</span></label>
                        </div>

                        <div class="form-group form-check">
                            <input type="checkbox" name="catchall" value="catch all" class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_catchall == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables with Risk <span class="badge badge-info">{{ $count_catchall }}</span></label>
                        </div>

                    </div>

                </div>
                <script>
                    function cbChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_all_{{ $i }}");
                        cbs[0].checked = false;
                    }

                    function allChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_sub_{{ $i }}");
                        for (var i = 0; i < cbs.length; i++) {
                            cbs[i].checked = false;
                        }
                    }
                </script>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Download</button>
                </div>
            </form>
        </div>
    </div>
</div>
    <!-- Text Download Modal -->
<div class="csv_download modal fade" id="model_text{{ $csv_name_ex }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Text Download</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('downloadFile')}}" method="post">
                @csrf
                <input type="text" name="filename" hidden value="{{ $csv_name_ex }}">
                <input type="text" name="user_id" hidden value="{{ $user_id }}">
                <input type="text" name="type" hidden value="text">
                <div class="modal-body row">
                    <div class="col-sm-6">
                        <div class="form-group form-check">
                            <input type="checkbox" name="valid" value="valid" checked class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_valid == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables <span class="badge badge-success">{{ $count_valid }}</span></label>
                        </div>

                        <div class="form-group form-check">
                            <input type="checkbox" name="catchall" value="catch all" class="form-check-input check_sub_{{ $i }}" onchange="cbChange{{ $i }}(this)" id="checkbox_{{ ++$c }}" <?php if($count_catchall == 0){ echo 'disabled'; } ?>>
                            <label class="form-check-label" for="checkbox_{{ $c }}">Deliverables with Risk <span class="badge badge-info">{{ $count_catchall }}</span></label>
                        </div>

                    </div>

                </div>
                <script>
                    function cbChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_all_{{ $i }}");
                        cbs[0].checked = false;
                    }

                    function allChange{{$i}}(obj) {
                        var cbs = document.getElementsByClassName("check_sub_{{ $i }}");
                        for (var i = 0; i < cbs.length; i++) {
                            cbs[i].checked = false;
                        }
                    }
                </script>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Download</button>
                </div>
            </form>
        </div>
    </div>
</div>
    @php 
        $i++;
    @endphp
    @empty
    <h2>No any file plase upload!</h2>
    @endforelse

    @php
    $scan_timeout = '';
        $scan_port = '';
        $scan_mail = '';
        $d_estimated_cost = '';
        $logo_image = '';
        $site_options_row = \App\Models\Verify\SiteOption::get()->toArray();

        if (!empty($site_options_row)) {
            $logo_image = $site_options_row[0]['logo'];
            $app_title = $site_options_row[0]['site_title'];
            $scan_timeout = $site_options_row[0]['scan_time_out'];
            $scan_port = $site_options_row[0]['scan_port'];
            $scan_mail = $site_options_row[0]['scan_mail'];
            $d_estimated_cost = $site_options_row[0]['estimated_cost'];
            if (empty($logo_image)) {
                $logo_image = 'default_logo.png';
            }
            if (empty($app_title)) {
                $app_title = 'Email Verifier Pro';
            }
        } else {
            $logo_image = 'default_logo.png';
            $app_title = 'Email Verifier Pro';
        }
        @endphp
    <!-- End section or loop  -->

<script>
    $(document).ready(function() {

        $(".file_delete_btn").click(function() {
            var csvfile_name_d = $(this).attr("data-target");
            var user_id = "{{ $user_id }}";
            var delete_confirm = confirm("Are you sure?");
            if (delete_confirm) {
                $.ajax({
                    url: "{{ Route('deleteCsvFile') }}",
                    type: "post",
                    data: {
                        filename: csvfile_name_d,
                        uid: user_id,
                        _token: @json(csrf_token())
                    },
                    success: function(response) {
                        $('#mega_bar_'+csvfile_name_d).hide();
                    }
                });
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        $(".task-cancel-btn").click(function() {
            var csvfile_name_t = $(this).attr("data-target");
            var user_id = "{{ $user_id }}";
            $.ajax({
                url: "{{ Route('taskCancel') }}",
                type: "post",
                data: {
                    filename: csvfile_name_t,
                    uid: user_id,
                    _token: @json(csrf_token())
                },
                success: function(response) {
                    $('#preloader_'+csvfile_name_t).css('display', 'none');
                    $('#cancel_'+csvfile_name_t).css('display', 'block');
                }
            });
        });

        $(".verify-btn").click(function() {

            var from_mail = '{{ $scan_mail }}';
            var time_out = '{{ !empty($scan_timeout) ? $scan_timeout : 10 }}';
            var scan_port = '{{ !empty($scan_port) ? $scan_port : 25 }}';

            if (from_mail.length == 0) {
                alert('Please set time out and a from mail in settings page for continue scan');
                return false;
            }

            var csvfile_name = $(this).attr("data-target");
            $('.preloader').each(function(index, node) {
                if ($(node).attr('id') !== '#preloader_'+csvfile_name) {
                    $('#'+$(node).attr('id')).css('display', 'none');
                    $('#cancel_'+$(node).attr('id').replace('preloader_', '')).css('display','block');
                }
            });

            var csv_name_ex = csvfile_name.replace(/\.[^/.]+$/, "");
            $(this).parents('.verify_email').hide();
            $(this).parents('.verify_email_bulk').hide();
            $(this).parents('.verify_email_respond').hide();
            $('#preloader_'+csv_name_ex).css('display', 'block');
            var count_valid = parseInt($('#valid_'+csv_name_ex).html());
            var count_invalid = parseInt($('#invalid_'+csv_name_ex).html());
            var count_catchall = parseInt($('#catchall_'+csv_name_ex).html());
            var count_unknown = parseInt($('#unknown_'+csv_name_ex).html());
            var count_syntex = parseInt($('#syntax_'+csv_name_ex).html());
            var count_free = parseInt($('#free_account_'+csv_name_ex).html());
            var count_role = parseInt($('#role_account_'+csv_name_ex).html());
            var count_disponsable = parseInt($('#disposable_'+csv_name_ex).html());
            var user_id = {{$user_id}};
                $.ajax({                
                url: "{{ route('prefix_verify_emails') }}",                
                type: "post",
                data: { filename:csvfile_name, uid:user_id,frommail:from_mail,timeout:time_out,scan_port:scan_port,_token: @json(csrf_token()) },
                success: function (response) {
                window.location.reload( false );
                }
            });
        });
        
        $(".verify-bulk-btn").click(function() {

            var from_mail = '{{ $scan_mail }}';
            var time_out = '{{ !empty($scan_timeout) ? $scan_timeout : 10 }}';
            var scan_port = '{{ !empty($scan_port) ? $scan_port : 25 }}';

            if (from_mail.length == 0) {
                alert('Please set time out and a from mail in settings page for continue scan');
                return false;
            }

            var csvfile_name = $(this).attr("data-target");
            $('.preloader').each(function(index, node) {
                if ($(node).attr('id') !== '#preloader_'+csvfile_name) {
                    $('#'+$(node).attr('id')).css('display', 'none');
                    $('#cancel_'+$(node).attr('id').replace('preloader_', '')).css('display',
                        'block');
                }
            });

            var csv_name_ex = csvfile_name.replace(/\.[^/.]+$/, "");
            $(this).parents('.verify_email').hide();
            $(this).parents('.verify_email_bulk').hide();
            $(this).parents('.verify_email_respond').hide();
            $('#preloader_'+csv_name_ex).css('display', 'block');
            var count_valid = parseInt($('#valid_'+csv_name_ex).html());
            var count_invalid = parseInt($('#invalid_'+csv_name_ex).html());
            var count_catchall = parseInt($('#catchall_'+csv_name_ex).html());
            var count_unknown = parseInt($('#unknown_'+csv_name_ex).html());
            var count_syntex = parseInt($('#syntax_'+csv_name_ex).html());
            var count_free = parseInt($('#free_account_'+csv_name_ex).html());
            var count_role = parseInt($('#role_account_'+csv_name_ex).html());
            var count_disponsable = parseInt($('#disposable_'+csv_name_ex).html());
            var bulk_status = 1;
            var user_id = {{$user_id}};
                $.ajax({                
                url: "{{ route('prefix_verify_emails') }}",                
                type: "post",
                data: { filename:csvfile_name, bulk_status:bulk_status, uid:user_id,frommail:from_mail,timeout:time_out,scan_port:scan_port,_token: @json(csrf_token()) },
                success: function (response) {
                window.location.reload( false );
                }
            });
        });

        $(".verify-bulk-followup-btn").click(function() {

            var from_mail = '{{ $scan_mail }}';
            var time_out = '{{ !empty($scan_timeout) ? $scan_timeout : 10 }}';
            var scan_port = '{{ !empty($scan_port) ? $scan_port : 25 }}';

            if (from_mail.length == 0) {
                alert('Please set time out and a from mail in settings page for continue scan');
                return false;
            }

            var csvfile_name = $(this).attr("data-target");
            $('.preloader').each(function(index, node) {
                if ($(node).attr('id') !== '#preloader_'+csvfile_name) {
                    $('#'+$(node).attr('id')).css('display', 'none');
                    $('#cancel_'+$(node).attr('id').replace('preloader_', '')).css('display',
                        'block');
                }
            });

            var csv_name_ex = csvfile_name.replace(/\.[^/.]+$/, "");
            $(this).parents('.verify_email').hide();
            $(this).parents('.verify_email_bulk').hide();
            $(this).parents('.verify_email_respond').hide();
            $('#preloader_'+csv_name_ex).css('display', 'block');
            var count_valid = parseInt($('#valid_'+csv_name_ex).html());
            var count_invalid = parseInt($('#invalid_'+csv_name_ex).html());
            var count_catchall = parseInt($('#catchall_'+csv_name_ex).html());
            var count_unknown = parseInt($('#unknown_'+csv_name_ex).html());
            var count_syntex = parseInt($('#syntax_'+csv_name_ex).html());
            var count_free = parseInt($('#free_account_'+csv_name_ex).html());
            var count_role = parseInt($('#role_account_'+csv_name_ex).html());
            var count_disponsable = parseInt($('#disposable_'+csv_name_ex).html());
            var user_id = {{$user_id}};
            var bulk_status = 1;
            var follwup_status = 1;
                $.ajax({                
                url: "{{ route('prefix_verify_emails') }}",                
                type: "post",
                data: { filename:csvfile_name, bulk_status:bulk_status, follwup_status:follwup_status, uid:user_id,frommail:from_mail,timeout:time_out,scan_port:scan_port,_token: @json(csrf_token()) },
                success: function (response) {
                window.location.reload( false );
                }
            });
        });
    });
</script>

</div>
</div>
</div>

<!-- Add List Modal-->
<div class="modal fade" id="addList" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Upload Your File (CSV, Xlsx, xls, text)</h4><hr>
                
            <form action="{{ Route('saveEmail') }}" method="post"enctype="multipart/form-data" >
                @csrf
                    <input style="margin:auto; padding:50px" class="form-control-file" type="file" name="filename">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Upload Now</button>
                    </div>
            </form>
            </div>
        </div>
    </div>
</div>
<!-- End List Model  -->

@endsection