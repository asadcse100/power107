<?php
// error_reporting( E_ALL );
// ini_set( 'display_errors', 1);
// if(isset($title)){
// include (($title == 'dashboard') ? '': '../').'functions/pagename.php';
// include (($title == 'dashboard') ? '': '../').'functions/'.$session;

// if($title == 'dashboard'){
//   Session::checkSession_d(); //check login session for index page
// }else{
//   Session::checkSession(); // check login for others page
// }

// if(isset($_GET['action']) && $_GET['action'] == "logout"){
//   if($title == 'dashboard'){
//     Session:: destroy_d();
//   }else{
//     Session:: destroy();
//   }
// }

// if($title == 'dashboard' && !isset($_SESSION['lic_chck']) && !isset($_SESSION['licance_error'])) {
//   header('location:app/'.$lic_chck);
// }

$user_id = Auth::id();
//dd($user_id);
// global $s_path;

// $user_id = $_SESSION['id'];
// $fname = $_SESSION['fname'];
// $image = $_SESSION['image'];


// include (($title == 'dashboard') ? '': '../').'config/'.$config;
// include (($title == 'dashboard') ? '': '../').'config/'.$database;
// include (($title == 'dashboard') ? '': '../').'functions/'.$user_wallet_func;
// $db = new database();

// $user_data_sql = "SELECT * FROM users WHERE id = '$user_id'";
// $user_data_sql = \App\Models\Verify\UserEmailList::select('email_name')->where('csv_file_name', $csv_file_name)->where('email_status', 'valid')->where('user_id',$user_id)->count();
// $user_data_read = $db->select($user_data_sql);

$scan_timeout = '';
$scan_port = '';
$scan_mail = '';
$d_estimated_cost = '';
$logo_image = '';

// $site_options_sql = "SELECT * FROM site_options";
// $site_options_read = $db->select($site_options_sql);


$site_options_row = \App\Models\Verify\SiteOption::get()->toArray();

// dd($site_options_row);


    //$site_options_check = mysqli_num_rows($site_options_read);
    if (!empty($site_options_row)) {
      //$site_options_row = $site_options_read->fetch_assoc();
      $logo_image = $site_options_row[0]['logo'];
      $app_title = $site_options_row[0]['site_title'];
      $scan_timeout = $site_options_row[0]['scan_time_out'];
      $scan_port = $site_options_row[0]['scan_port'];
      $scan_mail = $site_options_row[0]['scan_mail'];
    //   dd($scan_mail);
      $d_estimated_cost = $site_options_row[0]['estimated_cost'];
      $s_path =  $site_options_row[0]['script_path'];
      $s_url =  $site_options_row[0]['script_url'];
      // $lic_key =  $site_options_row['license_key'];
      $lic_type =  $site_options_row[0]['license_title'];
      $lic_exp =  $site_options_row[0]['license_exp'];
      $lic_support = $site_options_row[0]['license_support'];
      if(empty($logo_image)){
        $logo_image = 'default_logo.png';
      }
      if(empty($app_title)){
        $app_title = 'Email Verifier Pro';
      }
    }else{
      $logo_image = 'default_logo.png';
      $app_title = 'Email Verifier Pro';
    }


?>