@extends('layouts.app')
@section('content')

<div class="content">
    <div class="clearfix"></div>
    <div class="clearfix"></div>
  

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">

            <div class="row">
            <div class="col-md-6">
                <div class="card shadow p-4 ml-1 mt-3 mb-3">
                <?php if(isset($_SESSION['action']) && isset($_SESSION['action_cat']) && $_SESSION['action_cat'] == 'scan_mail_settings'){ ?>
                                <span class="text-<?php echo $_SESSION['action'] ? 'danger' : 'success'; ?>"><?php echo isset($_SESSION['action_message']) ? $_SESSION['action_message'] : ''; ?></span>
                                <?php } ?>
                    <h5 class="">Scan Mail Settings</h5>
                    <div class="setting-box mt-4">
                        <form action="{{ route('scan_mail_settings') }}" method="post">
                            @csrf
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Scan from mail</label>
                                <div class="col-sm-8">
                                <input type="email" required name="scan_from" class="form-control" value="<?php echo !empty($scan_mail) ? $scan_mail : ''; ?>" placeholder="enter your scan from mail">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">SMTP Scan Port</label>
                                <div class="col-sm-8">
                                <input type="number" required name="scan_port" class="form-control" value="<?php echo !empty($scan_port) ? $scan_port : ''; ?>" placeholder="enter your server open smtp port for scan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">scan timeout per email (in sec)</label>
                                <div class="col-sm-8">
                                    <input type="number" required name="timeout" class="form-control" value="<?php echo (!empty($scan_timeout) ? $scan_timeout: '');?>" placeholder="Enter timeout value (default 10 sec)">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="float-right">
                                    <button type="submit" name="scan_mail_settings" class="btn btn-sm btn-info">Save</button>
                                </div>
                            </div>
                        </form>
                    </div> 
                </div>
            </div>
        </div>


            </div>
        </div>
        <div class="text-center">
        

        </div>
    </div>

    <script>
        // Email and Domain type Filter
        $('#add-more-btn').click(function() {
            var count_more_cont = $('.add-more-type-cont').length;
            if (count_more_cont <= 0) {
                var index = 1;
            } else {
                var last_count = $('.add-more-type-cont').last().attr('id');
                var last_count = last_count.substring(last_count.lastIndexOf("-") + 1, last_count.length);
                var index = parseInt(last_count) + 1;
            }
            if (count_more_cont < 9) {
                $('#add-account-type-sec').append('<div id="add-more-' + index +
                    '" class="row mb-2 add-more-type-cont"> <input required hidden name="listing_value[]" value="' +
                    index + '"> <div class="col-md-5"><input required type="text" name="name_' + index +
                    '" class="form-control form-control-sm" value="" placeholder="Enter Domain Name"></div><div class="col-md-5"><div class="input-group input-group-sm"><select required name="type_' +
                    index +
                    '" class="custom-select form-control form-control-sm" id="inputGroupSelect04" aria-label="Example select with button addon"><option value="" selected>Select Account type</option><option value="Free Account">Free Account</option><option value="Role Account">Role Account</option><option value="Disposable Account">Disposable</option></select><div class="input-group-append ml-1"><button id="' +
                    index +
                    '" class="btn btn-outline-secondary cancel-btn-more-type" type="button"><i class="fas fa-times"></i></button></div></div></div></div>'
                );
            } else {
                $('#add-more-error').text('Cannot add more than 10 item at a time!');
            }
            $('.cancel-btn-more-type').click(function() {
                var get_id_value = $(this).attr('id');
                console.log(get_id_value);
                $('#add-more-' + get_id_value).remove();
                $('#add-more-error').text('');
            })
        });
        $('.edit-btn').click(function() {
            var target_id = $(this).attr('data-target');
            var index_id = $(this).attr('table-id');
            var target_name = document.getElementById("name_" + index_id).innerHTML;
            var target_type = document.getElementById("type_" + index_id).innerHTML;
            $('#edit-target-value').text(index_id + '. Update Value');
            console.log(target_id);
            $('#edit-target-name').val(target_name);
            $("#edit-target-type").val(target_type);
            $("#target-id").val(target_id);
            $('#edit-sec').css('display', 'block');
            $('#add-sec').css('display', 'none');
        });
        $('#cancel-edit').click(function() {
            $('#edit-sec').css('display', 'none');
            $('#add-sec').css('display', 'block');
        });
    </script>
    
@endsection